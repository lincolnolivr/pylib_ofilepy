# ofilepy-pylib
A library to make easier work with files in local system
